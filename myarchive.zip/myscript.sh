echo "hello"
echo "pwd in script"
pwd

echo "ls in script"
ls
